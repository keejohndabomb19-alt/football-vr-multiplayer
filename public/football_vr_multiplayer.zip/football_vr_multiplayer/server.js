const express = require('express');
const http = require('http');
const path = require('path');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });
const PORT = process.env.PORT || 3000;
const rooms = new Map();
app.use(express.static(path.join(__dirname, 'public')));
app.get('/health', (_req, res) => res.json({ ok: true, game: 'Football VR Multiplayer' }));

const startBall = () => ({ x: 0, y: 0.23, z: 1.7, vx: 0, vy: 0, vz: 0, moving: false });
function getRoom(code) {
  if (!rooms.has(code)) rooms.set(code, { players: new Map(), ball: startBall(), score: { home: 0, away: 0 }, lastMessage: 'Match ready.' });
  return rooms.get(code);
}
function publicPlayer(id, p) { return { id, name: p.name, color: p.color, x: p.x, y: p.y, z: p.z, yaw: p.yaw }; }
function broadcastBall(code, room, message='') {
  io.to(code).emit('ballState', { x: room.ball.x, y: room.ball.y, z: room.ball.z, score: room.score, message });
}
io.on('connection', socket => {
  socket.on('joinRoom', payload => {
    const code = String(payload?.room || 'KICKOFF').toUpperCase().replace(/[^A-Z0-9_-]/g, '').slice(0,12) || 'KICKOFF';
    const room = getRoom(code);
    if (room.players.size >= 8) { socket.emit('roomFull'); return; }
    if (socket.data.room) {
      const old = getRoom(socket.data.room); old.players.delete(socket.id); socket.leave(socket.data.room);
      io.to(socket.data.room).emit('playerLeft', socket.id);
    }
    const palette = [0x58a6ff,0xff7b72,0x8bdf91,0xd6a5ff,0xffc66d,0x75e0d0,0xff9ed2,0xd5e0ee];
    const player = { name: String(payload?.name || 'Player').slice(0,18), color: palette[room.players.size % palette.length], x: 0, y: 0, z: 6 + room.players.size * 0.6, yaw: 0, lastKick: 0 };
    room.players.set(socket.id, player); socket.data.room = code; socket.join(code);
    socket.emit('joined', { id: socket.id, players: [...room.players.entries()].map(([id,p]) => publicPlayer(id,p)), ball: room.ball, score: room.score });
    socket.to(code).emit('playerJoined', publicPlayer(socket.id, player));
  });
  socket.on('pose', pose => {
    const code = socket.data.room; if (!code) return;
    const room = rooms.get(code), p = room?.players.get(socket.id); if (!p) return;
    // Clamp incoming coordinates to avoid wildly malformed player positions.
    p.x = clamp(Number(pose?.x) || 0, -30, 30); p.y = clamp(Number(pose?.y) || 0, 0, 5);
    p.z = clamp(Number(pose?.z) || 0, -55, 25); p.yaw = clamp(Number(pose?.yaw) || 0, -Math.PI*2, Math.PI*2);
    socket.to(code).emit('playerState', publicPlayer(socket.id,p));
  });
  socket.on('kick', payload => {
    const code = socket.data.room; if (!code) return;
    const room = rooms.get(code), p = room?.players.get(socket.id); if (!p) return;
    const now = Date.now(); if (now - p.lastKick < 450) return; p.lastKick = now;
    const d = payload?.direction || {};
    let dx = clamp(Number(d.x)||0, -1, 1), dy = clamp(Number(d.y)||0.25, -0.4, 1), dz = clamp(Number(d.z)||-1, -1, -0.1);
    const len = Math.hypot(dx,dy,dz) || 1; dx/=len;dy/=len;dz/=len;
    room.ball.vx = dx * 17; room.ball.vy = Math.max(2.2,dy*17); room.ball.vz = dz*17; room.ball.moving = true;
    broadcastBall(code,room,`${p.name} took a shot!`);
  });
  socket.on('disconnect', () => {
    const code = socket.data.room; if (!code) return;
    const room = rooms.get(code); if (!room) return;
    room.players.delete(socket.id); socket.to(code).emit('playerLeft',socket.id);
    if (room.players.size === 0) rooms.delete(code);
  });
});
function clamp(n,min,max){return Math.max(min,Math.min(max,n));}

// Simple authoritative ball simulation, shared by everyone in each room.
setInterval(() => {
  const dt = 1/30;
  for (const [code,room] of rooms) {
    const b=room.ball;
    if (b.moving) {
      b.vy -= 9.81*dt; b.x += b.vx*dt; b.y += b.vy*dt; b.z += b.vz*dt;
      if (b.y < .23) { b.y=.23; b.vy=Math.abs(b.vy)*.42; b.vx*=.82; b.vz*=.82; if(Math.hypot(b.vx,b.vy,b.vz)<1.3)b.moving=false; }
      // Goal plane and simple goal mouth test.
      if (b.z < -40.45 && b.z > -42 && Math.abs(b.x)<3.45 && b.y<2.25 && b.y>.12) {
        room.score.home++; Object.assign(room.ball,startBall()); broadcastBall(code,room,'GOAL!'); continue;
      }
      if (b.z < -44 || b.z > 14 || Math.abs(b.x)>22) { Object.assign(room.ball,startBall()); broadcastBall(code,room,'Missed! Ball reset.'); continue; }
    }
    io.to(code).emit('ballState',{x:b.x,y:b.y,z:b.z,score:room.score,message:''});
  }
}, 1000/30);

server.listen(PORT, () => console.log(`Football VR server listening on port ${PORT}`));
