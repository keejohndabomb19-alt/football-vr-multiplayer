# Football VR Multiplayer (WebXR)

A starter multiplayer football prototype for Meta Quest 3 using Three.js, WebXR, Node.js and Socket.IO.

## What works in this prototype
- Multiple Quest/browser players join the same room code.
- Server relays player head positions to create simple remote avatars.
- Everyone in a room sees the same ball position and score.
- Controller trigger kicks when the controller is aimed toward the ball.
- A simple server-side ball simulation and goal counter.
- Desktop browser preview.

## Run locally for development
You need Node.js 18+ installed.

1. Open a terminal in this project folder.
2. Run `npm install`.
3. Run `npm start`.
4. Open `http://localhost:3000` on your computer.

For VR, the site needs a secure context. `localhost` is generally considered secure only on the same computer, so to use Quest headsets you must deploy the Node app to a public HTTPS host that supports persistent WebSocket connections (for example a suitable Node hosting service). Both players open the same HTTPS URL, enter the same room code, then press Join match. Press Enter VR to enter immersive mode.

## Deploying
Deploy this project as a Node.js web service, not as a static-only site, because Socket.IO requires the running server. Set the start command to `npm start`; the host will provide `PORT`. Ensure WebSocket connections are supported. The HTML is served from `public/index.html`.

## Current limitations
This is a learning prototype, not a finished game. The player avatars are simplified; only head pose/yaw is networked (not tracked hands/body). The shared ball simulation is basic, there is no teams/match clock/real collision system/anti-cheat, and the goal logic is prototype-level. Test on actual headsets and a public deployed server before sharing with friends.
